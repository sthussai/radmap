

		<div class="w3-container">

			Set Color
			<input wire:model="color" type="color">

			<p class="w3-white">Color is <?php echo e($color); ?></p>  <br>
			<input wire:model="btnName" type="text"> Button text: <?php echo e($btnName); ?> <button><?php echo e($btnName); ?></button>

			<button wire:click="emitFoo('<?php echo e($color); ?>')">Save</button>

			<button id="find" class="myBtn" onclick="locateMe(map);" title="Find My Location"><?php echo e($btnName); ?>

				<span id="btn-loader" style="display:none" class="loader-1" title="Find My Location"></span>
			</button>
			<button id="stop" style="display: none" class="myBtn" onclick="stopLocating(map);"
				title="Stop Location Sharing">Stop</button>

			<button class="menuBtn" style="background-color:<?php echo e($color); ?>" onclick="openNav();" title="Open Menu">
				<i class="fa fa-question w3-large "></i></button>
		</div>			




<!-- <script>
    
    var Test1 = "<?php echo e($color); ?>";

    console.log("<?php echo e($color ? $color : 'Default color'); ?>");
</script> --><?php /**PATH C:\xampp\htdocs\Radmap\resources\views/livewire/hello-world.blade.php ENDPATH**/ ?>