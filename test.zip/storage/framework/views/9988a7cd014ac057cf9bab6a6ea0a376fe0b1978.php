<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Rad Map</title>

  <!-- Scripts -->
  <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

  <!-- Fonts -->
  <link rel="dns-prefetch" href="//fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

  <!-- Styles -->
  <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

  <!-- Styles -->
  <style>
    html,
    body {
      background-color: #fff;
      color: #636b6f;
      font-family: 'Nunito', sans-serif;
      font-weight: 200;
      height: 100vh;
      margin: 0;
    }



    .flex-center {
      align-items: center;
      display: flex;
      justify-content: center;
    }

    .position-ref {
      position: relative;
    }

    .top-right {
      position: absolute;
      right: 10px;
      top: 18px;
    }

    .content {
      text-align: center;
    }

    .title {
      font-size: 54px;
    }

    .links>a {
      color: #636b6f;
      padding: 0 25px;
      font-size: 13px;
      font-weight: 600;
      letter-spacing: .1rem;
      text-decoration: none;
      text-transform: uppercase;
    }

    .m-b-md {
      margin-top: 20px;
      margin-bottom: 20px;
    }





    #feedback-page {
      text-align: center;
    }

    #form-main {
      width: 100%;
      float: left;
      padding-top: 0px;
    }

    #form-div {
      background-color: rgba(72, 72, 72, 0.4);
      padding-left: 35px;
      padding-right: 35px;
      padding-top: 35px;
      padding-bottom: 50px;
      width: 450px;
      float: left;
      left: 50%;
      position: absolute;
      margin-top: 30px;
      margin-left: -260px;
      border-radius: 7px;
      -moz-border-radius: 7px;
      -webkit-border-radius: 7px;
    }

    .feedback-input {
      color: #3c3c3c;
      font-family: Helvetica, Arial, sans-serif;
      font-weight: 500;
      font-size: 18px;
      border-radius: 0;
      line-height: 22px;
      background-color: #fbfbfb;
      padding: 13px 13px 13px 54px;
      margin-bottom: 10px;
      width: 100%;
      -webkit-box-sizing: border-box;
      -moz-box-sizing: border-box;
      -ms-box-sizing: border-box;
      box-sizing: border-box;
      border: 3px solid rgba(0, 0, 0, 0);
    }

    .feedback-input:focus {
      background: #fff;
      box-shadow: 0;
      border: 3px solid #3498db;
      color: #3498db;
      outline: none;
      padding: 13px 13px 13px 54px;
    }

    .focused {
      color: #30aed6;
      border: #30aed6 solid 3px;
    }

    /* Icons ---------------------------------- */


    textarea {
      width: 100%;
      height: 150px;
      line-height: 150%;
      resize: vertical;
    }

    input:hover,
    textarea:hover,
    input:focus,
    textarea:focus {
      background-color: white;
    }

    #button-blue {
      font-family: 'Montserrat', Arial, Helvetica, sans-serif;
      float: left;
      width: 100%;
      border: #fbfbfb solid 4px;
      cursor: pointer;
      background-color: #3498db;
      color: white;
      font-size: 24px;
      padding-top: 22px;
      padding-bottom: 22px;
      -webkit-transition: all 0.3s;
      -moz-transition: all 0.3s;
      transition: all 0.3s;
      margin-top: -4px;
      font-weight: 700;
    }

    #button-blue:hover {
      background-color: rgba(0, 0, 0, 0);
      color: #0493bd;
    }

    .submit:hover {
      color: #3498db;
    }

    .ease {
      width: 0px;
      height: 74px;
      background-color: #fbfbfb;
      -webkit-transition: .3s ease;
      -moz-transition: .3s ease;
      -o-transition: .3s ease;
      -ms-transition: .3s ease;
      transition: .3s ease;
    }

    .submit:hover .ease {
      width: 100%;
      background-color: white;
    }
  </style>
</head>

<body>

  <div class="flex-center position-ref full-height">

    <div class="content">
      <div class="title m-b-md">
        Rad Map
      </div>


      <div class="w3-container">
        <hr id="contact">

        <h3 class="w3-padding-16 w3-center w3-text-black">Feedback</h3>
        <p>

          Have Suggestions? Notice an error? Let us know!
        </p>

        <form style="max-width:700px;margin:auto;" target=""
          class="w3-panel w3-border w3-round w3-border-grey w3-light-grey w3-padding-32 " id="form1" action="feedback"
          method="POST">
          <?php echo csrf_field(); ?>
          <?php if($errors->any()): ?>
          <div class="alert alert-danger">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
          <?php endif; ?>
          <?php if(session('message')): ?>
          <div class="alert alert-success">
            <?php echo e(session('message')); ?>

          </div>
          <?php endif; ?>
          <p class="name">
            <input name="name" type="text" class="feedback-input " placeholder="Name" id="name"
              value="<?php echo e(old('name')); ?>" />
          </p>
          <p class="email">
            <input name="email" type="text" class="feedback-input " placeholder="Email*" id="email"
              value="<?php echo e(old('email')); ?>" />
          </p>


          <p class="text">
            <textarea name="message" type="text" class="feedback-input" id="comment"
              placeholder="Comments*"><?php echo e(old('message')); ?></textarea>
          </p>
          <span class="w3-left w3-margin-bottom">*required</span>
          <div class="submit">
            <input type="submit" name="submit" value="Submit" id="button-blue" />

            <div class="ease"></div>
          </div>
        </form>

        <div class="links" style="margin-top:10px">
          <a href="/">Back</a>
        </div>

      </div>
    </div>

</body>

</html><?php /**PATH C:\xampp\htdocs\Radmap\resources\views/feedback.blade.php ENDPATH**/ ?>