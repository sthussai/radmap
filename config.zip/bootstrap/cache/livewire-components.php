<?php return array (
  'hello-world' => 'App\\Http\\Livewire\\HelloWorld',
  'radmapmain' => 'App\\Http\\Livewire\\Radmapmain',
);