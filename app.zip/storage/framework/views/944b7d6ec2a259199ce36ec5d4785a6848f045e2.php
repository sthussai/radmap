


<?php $__env->startSection('content'); ?>

<!-- <?php if(Route::has('login')): ?>
        <div id="topDiv" class="top-right links">
            <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(url('/home')); ?>">Home</a>
            <?php else: ?>
            <a href="<?php echo e(route('login')); ?>">Login</a>
                <?php endif; ?>
        </div>
        <?php endif; ?> -->
    <div id="mainDiv">
        <!-- Content loaded via AJAX -->
    </div>

    <script>

            $.ajax({
                url: '/ajaxviews/welcome.html',
                dataType: 'html',
                success: function(data){
                    $('#mainDiv').html(data);
                }
            });
        

        $('#about').click(function(){
            window.history.pushState("object or string", "Page Title", "/about")
        });

        window.addEventListener('popstate', function (event) {
            if (window.location.pathname == "/about" ){
                $("#topDiv").hide();
                    $.ajax({
                        url: '/ajaxviews/about.html',
                        dataType: 'html',
                        success: function(data){
                            $('#mainDiv').html(data);
                        }
                    })
                }
        });


    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.map', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Radmap\resources\views/welcome.blade.php ENDPATH**/ ?>