

<?php $__env->startSection('title', 'Feedback'); ?>

<?php $__env->startSection('content'); ?>

 

  <div class="flex-center position-ref ">

    <div class="content">
      <div class="title m-b-md" style="font-size: 45px; font-weight: 10; margin-bottom:0">Rad Map</div>


      <div class="w3-container">
        <hr id="contact">

        <h3 class="w3-padding-16 w3-center w3-text-black">Feedback</h3>
        <p>

          Have Suggestions? Notice an error? Let us know!
        </p>

        <form style="max-width:700px;margin:10px auto;"
          class="w3-panel w3-border w3-round w3-border-grey w3-light-grey w3-padding-32 " id="form1" action="feedback"
          method="POST">
          <?php echo csrf_field(); ?>
          <?php if($errors->any()): ?>
          <div class="alert alert-danger">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
          <?php endif; ?>
          <?php if(session('message')): ?>
          <div class="alert alert-success">
            <?php echo e(session('message')); ?>

          </div>
          <?php endif; ?>
          <p class="name">
            <input name="name" type="text" class="feedback-input " placeholder="Name" id="name"
              value="<?php echo e(old('name')); ?>" />
          </p>
          <p class="email">
            <input name="email" type="text" class="feedback-input " placeholder="Email*" id="email"
              value="<?php echo e(old('email')); ?>" required />
          </p>


          <p class="text">
            <textarea name="message" type="text" class="feedback-input" id="comment"
              placeholder="Comments*" required ><?php echo e(old('message')); ?></textarea>
          </p>
          <div class="submit">
            <input type="submit" name="submit" value="Submit" id="button-blue" />
            
            <div class="ease"></div>
          </div>
          <span class="w3-left w3-margin-bottom">*required</span>
        </form>

        <div class="links" style="margin:20px">
          <a href="/">Home</a>
        </div>

      </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.map', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Radmap\resources\views/feedback.blade.php ENDPATH**/ ?>